package com.example.https;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
